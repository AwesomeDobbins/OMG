# Hide PowerShell Window
$i = '[DllImport("user32.dll")] public static extern bool ShowWindow(int handle, int state);'
add-type -name win -member $i -namespace native;
[native.win]::ShowWindow(([System.Diagnostics.Process]::GetCurrentProcess() | Get-Process).MainWindowHandle, 0);

# Function to Unmute and Set Volume to 100%
function Set-Volume100 {
    $o = New-Object -ComObject WScript.Shell
    # Unmute system audio
    $o.SendKeys([char]173)  
    Start-Sleep -Milliseconds 500
    # Set volume to 100% by pressing 'Volume Up' key multiple times
    for ($i = 0; $i -lt 50; $i++) { $o.SendKeys([char]175) }  
}

# Function to Detect Mouse Movement
function Target-Comes {
    Add-Type -AssemblyName System.Windows.Forms
    $originalPOS = [System.Windows.Forms.Cursor]::Position.X
    $o = New-Object -ComObject WScript.Shell

    while ($true) {
        Start-Sleep -Seconds 1
        if ([System.Windows.Forms.Cursor]::Position.X -ne $originalPOS) {
            break
        } else {
            # Press CAPS LOCK (optional distraction)
            $o.SendKeys("{CAPSLOCK}")
        }
    }
}

#########################################################################################################

# WPF Library for Playing Movie and some components
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.ComponentModel

# XAML File of WPF Window for Playing Movie
[xml]$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="PowerShell Video Player" WindowState="Maximized" ResizeMode="NoResize" WindowStartupLocation="CenterScreen">
        <MediaElement Stretch="Fill" Name="VideoPlayer" LoadedBehavior="Manual" UnloadedBehavior="Stop" />
</Window>
"@

# Movie Path
[uri]$VideoSource = "$env:TMP\rr.mp4"

# Parse XAML and Extract WPF Elements
$XAMLReader = (New-Object System.Xml.XmlNodeReader $XAML)
$Window = [Windows.Markup.XamlReader]::Load($XAMLReader)
$VideoPlayer = $Window.FindName("VideoPlayer")

# Wait for Mouse Movement
Target-Comes

# Unmute & Set Volume to 100%
Set-Volume100

# Set Video Player Properties
$VideoPlayer.Volume = 1  # WPF uses scale 0-1 (not 0-100)
$VideoPlayer.Source = $VideoSource

# Play Video
$VideoPlayer.Play()

# Show Window
$Window.ShowDialog() | Out-Null
